#include <LPC214x.h>

#define RAIN_SENSOR (1 << 21)  // P0.21 as input
#define FAN         (1 << 22)  // P0.22 as output

int main(void) {
    PINSEL1 &= ~0x00F00000;     // Clear function bits for P0.21 and P0.22 (GPIO)

    IO0DIR &= ~RAIN_SENSOR;     // Set P0.21 as input (Rain Sensor)
    IO0DIR |= FAN;              // Set P0.22 as output (Fan)

    while (1) {
        if ((IO0PIN & RAIN_SENSOR) == 0) {  // If rain sensor output is LOW
            IO0SET = FAN;       // Turn ON Fan
        } else {
            IO0CLR = FAN;       // Turn OFF Fan
        }

        // Short delay loop
        for (int i = 0; i < 50000; i++);
    }
}
