#include <LPC214x.h>

/* I/O Pins for the LDR and LED */
#define LDR_PIN (1 << 18)   // P0.8 as input
#define LED_PIN (1 << 19)  // P0.16 as output


// Initialize GPIO pins
void init_LDR_LED(void) {
    PINSEL0 &= ~0x000F0000;  // Clear P0.8 function bits (GPIO)
    PINSEL1 &= ~0x0000000C;  // Clear P0.16 function bits (GPIO)

    IO0DIR &= ~LDR_PIN;      // Set P0.8 as input (LDR)
    IO0DIR |= LED_PIN;       // Set P0.16 as output (LED)
}

// Read LDR value
unsigned int read_LDR(void) {
    return (IO0PIN & LDR_PIN);  // Return non-zero if HIGH
}

// Control LED
void led_on(void) {
    IO0SET = LED_PIN;
}

void led_off(void) {
    IO0CLR = LED_PIN;
}

