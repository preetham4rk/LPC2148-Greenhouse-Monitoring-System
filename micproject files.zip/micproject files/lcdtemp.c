#include <LPC214X.H>
#include <stdio.h>
#include <stdlib.h>
#include"mq3.h"
#include"ldr.h"
#define LCD (0xFFFF00FF)
#define RS (1<<4)
#define RW (1<<5)
#define EN (1<<6)
#define MQ3_SENSOR   (1 << 7)   // P0.7  - MQ3 sensor input
#define SPEAKER_PIN  (1 << 11)  // P0.11 - Speaker output
/* Define Digital I/O Pins for the LDR and LED */
#define LDR_PIN (1 << 18)   // P0.8 as input
#define LED_PIN (1 << 19)  // P0.16 as output
#define RAIN_SENSOR (1 << 17)  // P0.21 as input
#define FAN         (1 << 16)  // P0.22 as output
#define MQ9_PIN   (1 << 25)   // P0.9 as input
#define FAN_PIN   (1 << 26)  // P0.10 as output


void ADC_INIT(void);	     
int ADC(void);		     
void LCD_INIT(void);   	    
void LCD_CMD(char command);  
void LCD_STRING (char* msg); 
void delay_ms(int count);    
void UART0_INIT(void);       
void UART0_TX(char ch);      
void UART0_TX_STR(char *str);

int main (void)
{	  	
	int ADC_val, prev = -1;
	char val[30];

	PINSEL0 = 0x00000005;   // Enable UART0 TxD0(P0.0), RxD0(P0.1)
	IODIR0 |= (1<<20);  
	IO0DIR &= ~RAIN_SENSOR;     
    IO0DIR |= FAN;
	IO0DIR &= ~MQ9_PIN;       // P0.9 as input
    IO0DIR |= FAN_PIN;        // P0.10 as output          
    init_pins();
	init_LDR_LED();
	read_LDR();
	led_on();
	led_off();
	init_LDR_LED();
	UART0_INIT();
	ADC_INIT();  
	LCD_INIT(); 

	while (1)
	{	mq3_speaker_control(); 
		delay_ms(100);
		if (read_LDR()) {
            led_off();   // Turn on LED if LDR input is high
        } else {
            led_on();  // Turn off LED if LDR input is low
        }

		
        if ((IO0PIN & RAIN_SENSOR) == 0) {  // If rain sensor output is LOW
            IO0SET = FAN;       // Turn ON Fan
        } else {
            IO0CLR = FAN;       // Turn OFF Fan
        }
		
        if (IO0PIN & MQ9_PIN) {
            IO0SET = FAN_PIN;   // Turn on fan
        } else {
            IO0CLR = FAN_PIN;   // Turn off fan
		}
        

        delay_ms(100);
		ADC_val = ADC(); // Read ADC Value
		if (prev != ADC_val)
		{
			LCD_CMD(0x01);  // Clear Display
			sprintf(val, " Temp:%d C", ADC_val);
			LCD_STRING(val);
			LCD_CMD(0xC0);  // Move to second line

			// UART Output: Temperature
			UART0_TX_STR(val);
			UART0_TX_STR("\r\n");

			if (ADC_val > 30)
			{
				LCD_STRING("Status: Hot");
				UART0_TX_STR("Status: Hot\r\n");
				IOSET0 |= (1<<20);  // Turn ON LED
			}
			else
			{
				LCD_STRING("Status: Normal");
				UART0_TX_STR("Status: Normal\r\n");
				IOCLR0 |= (1<<20);  // Turn OFF LED
			}
			prev = ADC_val;
		}
		delay_ms(100);
	}
}

void UART0_INIT(void)
{
	U0LCR = 0x83;       
	U0DLM = 0x00;
	U0DLL = 97;         
	U0LCR = 0x03;       
}

void UART0_TX(char ch)
{
	while (!(U0LSR & 0x20)); // Wait for THR empty
	U0THR = ch;
}

void UART0_TX_STR(char *str)
{
	while (*str)
	{
		UART0_TX(*str++);
	}
}

void ADC_INIT(void)
{
	PINSEL1 &= 0xFF7FFFFF;
	PINSEL1 |= 0x00400000;  // P0.27 as AD0.0
	PCONP |= (1<<12);       // Enable ADC0
}

int ADC(void)
{
	unsigned int ADC_data;
	AD0CR = 0x00200701; // Select AD0.0, CLKDIV=VPB/8, PDN=1
	AD0CR |= (1<<24);   // Start conversion
	while (!(AD0GDR & 0x80000000));  // Wait for conversion
	ADC_data = (AD0GDR >> 6) & 0x3FF; 
	AD0CR &= 0xF8FFFFFF; // Stop conversion
	return (ADC_data * 3.3 / 1023.0) * 100; // Convert LM35 mV to Celsius
}

void LCD_INIT(void)
{
	IO0DIR |= 0x0000F070; 
	delay_ms(20);	
	LCD_CMD(0x02);  
	LCD_CMD(0x28);  
	LCD_CMD(0x06);  
	LCD_CMD(0x0C);  
	LCD_CMD(0x01);  
	LCD_CMD(0x80);  
}

void LCD_CMD(char command)
{
	IO0PIN = ((IO0PIN & LCD) | ((command & 0xF0)<<8)); 
	IO0SET = EN; 
	IO0CLR = (RS|RW); 
	delay_ms(5); 
	IO0CLR = EN; 
	delay_ms(5);

	IO0PIN = ((IO0PIN & LCD) | ((command & 0x0F)<<12)); 
	IO0SET = EN; 
	IO0CLR = (RS|RW); 
	delay_ms(5);
	IO0CLR = EN; 
	delay_ms(5);	
}

void LCD_STRING(char* msg)
{
	unsigned int i=0;
	while(msg[i]!=0)
	{
		IO0PIN = ((IO0PIN & LCD) | ((msg[i] & 0xF0)<<8));
		IO0SET = (RS|EN); 
		IO0CLR = RW; 
		delay_ms(2); 
		IO0CLR = EN; 
		delay_ms(5);

		IO0PIN = ((IO0PIN & LCD) | ((msg[i] & 0x0F)<<12)); 
		IO0SET = (RS|EN); 
		IO0CLR = RW; 
		delay_ms(2);
		IO0CLR = EN; 
		delay_ms(5);
		i++;
	}
}

void delay_ms(int count)
{
	int j=0,i=0;
	for(j=0;j<count;j++)
	{
		for(i=0;i<100;i++);
	}
}