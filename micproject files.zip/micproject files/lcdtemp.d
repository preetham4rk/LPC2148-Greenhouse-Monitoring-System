lcdtemp.o: lcdtemp.c
lcdtemp.o: C:\Keil\ARM\INC\Philips\LPC214X.H
lcdtemp.o: C:\Keil\ARM\RV31\INC\stdio.h
lcdtemp.o: C:\Keil\ARM\RV31\INC\stdlib.h
lcdtemp.o: mq3.h
lcdtemp.o: ldr.h
