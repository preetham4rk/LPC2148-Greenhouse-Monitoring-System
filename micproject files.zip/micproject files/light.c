#include <LPC214x.h>
#include <stdio.h>

// Pin Definitions
#define MQ3_SENSOR   (1 << 14)  // Changed to P0.14 for MQ3 gas sensor input
#define SPEAKER_PIN  (1 << 11)  // P0.11 as output (Speaker)
#define RELAY_INPUT  (1 << 10)  // P0.10 as input (LDR through relay)
#define LED_PIN      (1 << 2)   // P0.2 as output (LED indicator)

// Delay Functions
void Delay(void) {
    unsigned int i, j;
    for (i = 0; i < 1000; i++) {
        for (j = 0; j < 700; j++);
    }
}

void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 6000; j++);
    }
}

int main(void) {
    unsigned int ldr_status;

    // Configure directions
    IO0DIR &= ~RELAY_INPUT;     // Set P0.10 (relay input from LDR) as input
    IO0DIR &= ~MQ3_SENSOR;      // Set P0.14 (MQ3 gas sensor) as input
    IO0DIR |= SPEAKER_PIN;      // Set P0.11 as output (Speaker)
    IO0DIR |= LED_PIN;          // Set P0.2 as output (LED)

    while (1) {
        // Check MQ3 Gas Sensor
        if (IO0PIN & MQ3_SENSOR) {
            IO0SET = SPEAKER_PIN;  // Turn ON Speaker if gas is detected
        } else {
            IO0CLR = SPEAKER_PIN;  // Turn OFF Speaker
        }
		 
		  delay_ms(10);
        // Check LDR-controlled relay input
        ldr_status = IOPIN0 & RELAY_INPUT;
        if (ldr_status == RELAY_INPUT)
		{
            IOCLR0 |= LED_PIN;  // Turn OFF LED if switch open (no light)
        } else 
		{
            IOSET0 |= LED_PIN;  // Turn ON LED if switch closed (dark)
        }

		delay_ms(10);  // Small delay for stability
    }

    
}