/*Program to toggle all LED*/
#include <LPC17xx.h>

#define ALL_LED  (0xFF << 19)
#define BUZZER  (0x01 << 27)

void delay(int millis);

int main()
{
 //configure P1.26-P1.19 pins as output pins
 LPC_GPIO1->FIODIR |=  ALL_LED;

 //configure P1.27 pin as output pin
 LPC_GPIO1->FIODIR |=  BUZZER;


 while(1)
 {
 //turn on all leds
  LPC_GPIO1->FIOSET = ALL_LED;
  //turn off buzzer
  LPC_GPIO1->FIOCLR = BUZZER;

  delay(1000); // wait a while

  //turn off all leds
  LPC_GPIO1->FIOCLR = ALL_LED;
  //turn on buzzer
  LPC_GPIO1->FIOSET = BUZZER;

  delay(1000); // wait
   
 }
}

void delay(int millis)
{
int  i , j ;
for( i = 0 ; i < millis ; i ++ )
{
 for(j = 0 ; j < 1200 ; j ++) { }
}
}