.\uart.o: uart.c
