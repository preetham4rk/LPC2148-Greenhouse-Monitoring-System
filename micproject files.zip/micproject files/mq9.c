#include <LPC214x.h>

#define MQ9_PIN   (1 << 9)   // P0.9 as input
#define FAN_PIN   (1 << 10)  // P0.10 as output

int main(void) {
    
    PINSEL0 &= ~0x000FC000;   // Clear bits for P0.9 and P0.10

    // Set directions
    IO0DIR &= ~MQ9_PIN;       // P0.9 as input
    IO0DIR |= FAN_PIN;        // P0.10 as output

    while (1) {
        if (IO0PIN & MQ9_PIN) {
            IO0SET = FAN_PIN;   // Turn on fan
        } else {
            IO0CLR = FAN_PIN;   // Turn off fan
        }

        // Simple delay
        for (unsigned int i = 0; i < 1000000; i++);
    }
}
