/* Program to read temperature value and display on LCD */

#include <LPC17xx.h>
#include "lcd_header.h"
#include "uart_header.h"

int main()
{
    unsigned int adc_val;

    lcd_config();
    uart_config();

    /* Enable power to ADC */
    LPC_SC->PCONP |= (1 << 12);

    /* ADC Peripheral Clock = CCLK */
    LPC_SC->PCLKSEL0 |= (1 << 25) | (1 << 24);

    /* Configure P0.25 as AD0.2 */
    LPC_PINCON->PINSEL1 &= ~(3 << 18);
    LPC_PINCON->PINSEL1 |=  (1 << 19);

    /* ADC Control Register */
    LPC_ADC->ADCR = (1 << 2) | (4 << 8) | (1 << 16) | (1 << 21);

    while(1)
    {
        while(!(LPC_ADC->ADGDR & (1 << 31)));

        adc_val = (LPC_ADC->ADDR2 >> 4) & 0xFFF;

        adc_val = adc_val / 12.41;

        lcd_num(adc_val);
        uart_num(adc_val);

        delay(500);

        lcd_cmd(0x01);

        delay(500);
    }
}