#include <LPC214x.h>
#include <stdio.h>

#define MQ3_SENSOR_ADC_CHANNEL 0  // Channel 0 for ADC (P0.30)

void UART0_Init(void) {
    // Set the baud rate to 9600
    U0LCR = 0x83;  // 8 bits, 1 stop bit, no parity, DLAB=1
    U0DLM = 0;     // Divisor latch high byte
    U0DLL = 97;    // Divisor latch low byte for 9600 baud
    U0FCR = 0x07;  // Enable and reset FIFO
    U0LCR = 0x03;  // DLAB = 0
}

void UART0_SendChar(char c) {
    while (!(U0LSR & 0x20));  // Wait until the Transmit FIFO is empty
    U0THR = c;  // Send the character
}

void UART0_SendString(char *str) {
    while (*str) {
        UART0_SendChar(*str++);
    }
}

void ADC_Init(void) {
    // Configure ADC0 (P0.30) for 10-bit resolution
    PINSEL0 |= (1 << 15);  // Select ADC function for P0.30
    AD0CR = (1 << 0) | (1 << 2) | (1 << 21);  // Start ADC, select 10-bit mode
}

unsigned int ADC_Read(void) {
    unsigned int result;
    AD0CR |= (1 << 24);  // Start the conversion
    while (!(AD0GDR & (1 << 31)));  // Wait for the conversion to finish
    result = (AD0GDR >> 6) & 0x03FF;  // Get the result (10-bit value)
    return result;
}

int main() {
    unsigned int adcValue;
    char buffer[20];
    int i;  // Declare the variable i for delay loop

    UART0_Init();  // Initialize UART
    ADC_Init();    // Initialize ADC for MQ3

    while (1) {
        adcValue = ADC_Read();  // Read MQ3 sensor value
        sprintf(buffer, "ADC Value: %u\r\n", adcValue);  // Convert to string
        UART0_SendString(buffer);  // Send the value via UART
        
        // Delay (adjust as needed)
        for (i = 0; i < 1000000; i++) {
            // Empty loop for delay
        }
    }

    return 0;
}
