#include <LPC214x.h>

// Define MQ3 sensor and Speaker pin
#define MQ3_SENSOR   (1 << 7)   // P0.7  - MQ3 sensor input
#define SPEAKER_PIN  (1 << 11)  // P0.11 - Speaker output



// Function to initialize the pins
void init_pins(void) {
    IO0DIR &= ~MQ3_SENSOR;     // Set P0.7 as input (MQ3)
    IO0DIR |= SPEAKER_PIN;     // Set P0.11 as output (Speaker)
}

// Function to control the speaker based on MQ3
void mq3_speaker_control(void) {
    if (IO0PIN & MQ3_SENSOR) {
        IO0SET = SPEAKER_PIN;  // Turn ON speaker if gas detected
    } else {
        IO0CLR = SPEAKER_PIN;  // Turn OFF speaker if no gas
    }
}

// Delay function


// Main function

