#include <LPC214x.h>

// Define MQ3 sensor and Speaker pin
#define MQ3_SENSOR   (1 << 7)   // P0.7  - MQ3 sensor input
#define SPEAKER_PIN  (1 << 11)  // P0.11 - Speaker output

void delay_ms(unsigned int count);

// Function to initialize the pins
void init_pins(void) {
    IO0DIR &= ~MQ3_SENSOR;     // Set P0.7 as input (MQ3)
    IO0DIR |= SPEAKER_PIN;     // Set P0.11 as output (Speaker)
}

// Function to control the speaker based on MQ3
void mq3_speaker_control(void) {
    if (IO0PIN & MQ3_SENSOR) {
        IO0SET = SPEAKER_PIN;  // Turn ON speaker if gas detected
    } else {
        IO0CLR = SPEAKER_PIN;  // Turn OFF speaker if no gas
    }
}

// Delay function
void delay_ms(unsigned int count) {
    unsigned int i, j;
    for (i = 0; i < count; i++)
        for (j = 0; j < 12000; j++);
}

// Main function
int main(void) {
    init_pins();  // Initialize sensor and speaker pins

    while (1) {
        mq3_speaker_control(); // Continuously monitor MQ3
        delay_ms(100);         // Optional delay for stability
    }
}
