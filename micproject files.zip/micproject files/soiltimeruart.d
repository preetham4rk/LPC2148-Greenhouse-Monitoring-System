soiltimeruart.o: soiltimeruart.c
soiltimeruart.o: C:\Keil\ARM\INC\Philips\LPC214x.h
