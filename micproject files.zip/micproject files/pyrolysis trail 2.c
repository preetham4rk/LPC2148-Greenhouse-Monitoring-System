#include <LPC214x.h>

#define MQ3_SENSOR3 (1 << 25)  // P0.10 as input
#define LED_PIN7   (1 << 26)  // P0.11 as output
#define MQ3_SENSOR4 (1 << 27)  // P0.10 as input
#define LED_PIN8  (1 << 28)  // P0.11 as output

void delay_ms(unsigned int ms) {
unsigned int i, j;
for(i = 0; i < ms; i++)
for(j = 0; j < 6000; j++);  // Approximate delay
}

int main(void) {
// Configure P0.11 as output (LED), P0.10 as input (MQ3)
IO1DIR |= LED_PIN7;     // Set P0.11 as output
IO1DIR &= ~MQ3_SENSOR3; // Set P0.10 as input
IO1DIR |= LED_PIN8;     // Set P0.11 as output
IO1DIR &= ~MQ3_SENSOR4;

while(1) {
    if (IO1PIN & MQ3_SENSOR3) {
        IO1SET = LED_PIN7;   // Turn ON LED
    } else {
        IO1CLR = LED_PIN7;   // Turn OFF LED
    }
	if (IO1PIN & MQ3_SENSOR4) {
        IO1SET = LED_PIN8;   // Turn ON LED
    } else {
        IO1CLR = LED_PIN8;   // Turn OFF LED
    }

    delay_ms(100); // Optional debounce/delay
}




}	   19 as input 