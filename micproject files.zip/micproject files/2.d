2.o: 2.c
2.o: C:\Keil\ARM\INC\Philips\LPC214X.H
2.o: C:\Keil\ARM\RV31\INC\stdio.h
2.o: C:\Keil\ARM\RV31\INC\stdlib.h
