#include <LPC214X.H>
#include <stdio.h>
#include <stdlib.h>

#define LCD (0xFFFF00FF)
#define RS (1<<4)
#define RW (1<<5)
#define EN (1<<6)

void ADC_INIT(void);	     
int ADC(void);		     
void LCD_INIT(void);   	    
void LCD_CMD(char command);  
void LCD_STRING (char* msg); 
void delay_ms(int count);    
void UART0_INIT(void);       
void UART0_TX(char ch);      
void UART0_TX_STR(char *str);

int main (void)
{	  	
	int ADC_val, prev = -1;
	char val[30];

	PINSEL0 = 0x00000005;   // Enable UART0 TxD0(P0.0), RxD0(P0.1)
	IODIR0 |= (1<<20);      // P0.20 as output for LED

	UART0_INIT();
	ADC_INIT();  
	LCD_INIT(); 

	while (1)
	{	
		delay_ms(100);
		ADC_val = ADC(); // Read ADC Value
		if (prev != ADC_val)
		{
			LCD_CMD(0x01);  // Clear Display
			sprintf(val, " Temp:%d C", ADC_val);
			LCD_STRING(val);
			LCD_CMD(0xC0);  // Move to second line

			// UART Output: Temperature
			UART0_TX_STR(val);
			UART0_TX_STR("\r\n");

			if (ADC_val > 30)
			{
				LCD_STRING("Status: Hot");
				UART0_TX_STR("Status: Hot\r\n");
				IOSET0 |= (1<<20);  // Turn ON LED
			}
			else
			{
				LCD_STRING("Status: Normal");
				UART0_TX_STR("Status: Normal\r\n");
				IOCLR0 |= (1<<20);  // Turn OFF LED
			}
			prev = ADC_val;
		}
		delay_ms(100);
	}
}

void UART0_INIT(void)
{
	U0LCR = 0x83;       
	U0DLM = 0x00;
	U0DLL = 97;         
	U0LCR = 0x03;       
}

void UART0_TX(char ch)
{
	while (!(U0LSR & 0x20)); // Wait for THR empty
	U0THR = ch;
}

void UART0_TX_STR(char *str)
{
	while (*str)
	{
		UART0_TX(*str++);
	}
}

void ADC_INIT(void)
{
	PINSEL1 &= 0xFF7FFFFF;
	PINSEL1 |= 0x00400000;  // P0.27 as AD0.0
	PCONP |= (1<<12);       // Enable ADC0
}

int ADC(void)
{
	unsigned int ADC_data;
	AD0CR = 0x00200701; // Select AD0.0, CLKDIV=VPB/8, PDN=1
	AD0CR |= (1<<24);   // Start conversion
	while (!(AD0GDR & 0x80000000));  // Wait for conversion
	ADC_data = (AD0GDR >> 6) & 0x3FF; 
	AD0CR &= 0xF8FFFFFF; // Stop conversion
	return (ADC_data * 3.3 / 1023.0) * 100; // Convert LM35 mV to Celsius
}

void LCD_INIT(void)
{
	IO0DIR |= 0x0000F070; 
	delay_ms(20);	
	LCD_CMD(0x02);  
	LCD_CMD(0x28);  
	LCD_CMD(0x06);  
	LCD_CMD(0x0C);  
	LCD_CMD(0x01);  
	LCD_CMD(0x80);  
}

void LCD_CMD(char command)
{
	IO0PIN = ((IO0PIN & LCD) | ((command & 0xF0)<<8)); 
	IO0SET = EN; 
	IO0CLR = (RS|RW); 
	delay_ms(5); 
	IO0CLR = EN; 
	delay_ms(5);

	IO0PIN = ((IO0PIN & LCD) | ((command & 0x0F)<<12)); 
	IO0SET = EN; 
	IO0CLR = (RS|RW); 
	delay_ms(5);
	IO0CLR = EN; 
	delay_ms(5);	
}

void LCD_STRING(char* msg)
{
	unsigned int i=0;
	while(msg[i]!=0)
	{
		IO0PIN = ((IO0PIN & LCD) | ((msg[i] & 0xF0)<<8));
		IO0SET = (RS|EN); 
		IO0CLR = RW; 
		delay_ms(2); 
		IO0CLR = EN; 
		delay_ms(5);

		IO0PIN = ((IO0PIN & LCD) | ((msg[i] & 0x0F)<<12)); 
		IO0SET = (RS|EN); 
		IO0CLR = RW; 
		delay_ms(2);
		IO0CLR = EN; 
		delay_ms(5);
		i++;
	}
}

void delay_ms(int count)
{
	int j=0,i=0;
	for(j=0;j<count;j++)
	{
		for(i=0;i<100;i++);
	}
}
