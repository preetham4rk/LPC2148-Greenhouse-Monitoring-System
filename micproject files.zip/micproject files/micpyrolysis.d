micpyrolysis.o: micpyrolysis.c
micpyrolysis.o: C:\Keil\ARM\INC\Philips\LPC214X.H
micpyrolysis.o: C:\Keil\ARM\RV31\INC\stdio.h
micpyrolysis.o: C:\Keil\ARM\RV31\INC\stdlib.h
