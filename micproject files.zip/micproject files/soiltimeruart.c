#include <LPC214x.h>

// 74HC595 pins connected to LPC2148 GPIO0
#define DATA_PIN   (1<<0)   // P0.0
#define CLOCK_PIN  (1<<1)   // P0.1
#define LATCH_PIN  (1<<2)   // P0.2

void delay(unsigned int count)
{
    unsigned int i;
    for(i=0;i<count;i++);
}

// Send 8-bit data to 74HC595
void shiftOut(unsigned char data)
{
    unsigned char i;
    for(i=0;i<8;i++)
    {
        // Set DATA pin according to MSB first
        if(data & (1<< (7-i))) 
            IO0SET = DATA_PIN;   // Set DATA high
        else 
            IO0CLR = DATA_PIN;   // Set DATA low
        
        // Pulse CLOCK
        IO0SET = CLOCK_PIN;
        IO0CLR = CLOCK_PIN;
    }
    // Pulse LATCH
    IO0SET = LATCH_PIN;
    IO0CLR = LATCH_PIN;
}

// Read ADC value from AD0.3 (P0.30)
unsigned int ADC_Read(void)
{
    // Start conversion on channel 3
    AD0CR &= ~(0xFF);               // Clear previous SEL bits
    AD0CR |= (1UL<<3);              // Select AD0.3
    AD0CR |= (1UL<<24);             // Start conversion (START = 001)

    // Wait for DONE bit
    while((AD0DR3 & (1UL<<31)) == 0);

    // Return 10-bit result
    return ( (AD0DR3 >> 6) & 0x3FF );
}

int main(void)
{
    unsigned int adcValue;
    unsigned char ledData;

    // 1. Enable ADC0
    PCONP |= (1UL<<12);

    // 2. Configure P0.30 as AD0.3
    PINSEL1 &= ~(3<<28);
    PINSEL1 |=  (1<<28);

    // 3. Configure AD0CR
    AD0CR = (1UL<<3) |       // SEL = AD0.3
            (4<<8)  |       // CLKDIV = 4
            (1UL<<21);      // PDN = 1 (ADC enabled)

    // 4. Configure GPIO0 for 74HC595 pins
    IO0DIR |= DATA_PIN | CLOCK_PIN | LATCH_PIN; // Set P0.0,P0.1,P0.2 as output

    while(1)
    {
        adcValue = ADC_Read();           // Read ADC 0-1023

        // Map 10-bit ADC to 8-bit LED output (MSB)
        ledData = adcValue >> 2;         // 0-255

        // Send data to 74HC595
        shiftOut(ledData);

        delay(50000);                    // Simple delay
    }
}
