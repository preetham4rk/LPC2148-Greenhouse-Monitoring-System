#include <LPC17xx.h>

#define ALL_LED (0xFF << 19)

void SystemInit(void)
{
}

void delay(unsigned int time)
{
    unsigned int i, j;

    for(i = 0; i < time; i++)
    {
        for(j = 0; j < 1200; j++);
    }
}

int main(void)
{
    int left, right;
    LPC_GPIO1->FIODIR |= ALL_LED;
    while(1)
    {
        for(left = 26, right = 19; left >= 23; left--, right++)
        {
            LPC_GPIO1->FIOCLR = ALL_LED;
            LPC_GPIO1->FIOSET = (1 << left) | (1 << right);
            delay(1000);
        }
        for(left = 24, right = 21; left <= 26; left++, right--)
        {
            LPC_GPIO1->FIOCLR = ALL_LED;
            LPC_GPIO1->FIOSET = (1 << left) | (1 << right);
            delay(1000);
        }
    }
}