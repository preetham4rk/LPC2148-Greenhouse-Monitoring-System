soil.o: soil.c
soil.o: C:\Keil\ARM\INC\Philips\lpc214x.h
soil.o: C:\Keil\ARM\RV31\INC\stdio.h
