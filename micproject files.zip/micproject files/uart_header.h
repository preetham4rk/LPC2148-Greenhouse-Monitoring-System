/*Tx-P0.2
   Rx-P0.3, 
   DLL=146, DLM=0, DIV=1, MUL=15*/

   
void uart_config(void);
void uart_data(unsigned char a);   
void uart_str(unsigned char *ptr);   
void uart_num(unsigned int num);
unsigned char uart_data_receive(void);
//void delay(unsigned int a);

   /*UART Config*/
void uart_config(void)
{
	LPC_SC->PCONP|=(1<<3);						// Enable Power
	LPC_SC->PCLKSEL0&=~((1<<7)|(1<<6));					
	LPC_PINCON->PINSEL0|=(1<<4)|(1<<6);	 		// COnfig P0.2, P0.3 as TXd and Rxd

	LPC_UART0->LCR=(1<<0)|(1<<1)|(1<<7);		//8 bit Mode, No Parity,Enable DLAB Bit
	LPC_UART0->DLL=6;							//lOAD BaudRate Value for 9600
	LPC_UART0->DLM=0;
	LPC_UART0->FDR=(12<<4)|(1<<0);				//MUL=15, DIV=1

	LPC_UART0->LCR&=~(1<<7);					//Disable Divisor

}

		void uart_data_transmit(unsigned char a)
		{
		while(!(LPC_UART0->LSR &(1<<5)));	// Check THR empty or not using polling method
		LPC_UART0->THR=a;					//Load the data to be Transmitted to THR Reg
		delay(100);
		}
   
void uart_str(unsigned char *ptr)
{
   while(*ptr != '\0')
{
   uart_data_transmit(*ptr);
   ptr++;
}
}

void uart_num(unsigned int num)
{
  if(num)
  {
	uart_num(num/10);
	uart_data_transmit(num%10+0x30);
  }
  }

unsigned char uart_data_receive(void)
		{
		while(!(LPC_UART0->LSR &(1<<0)));	// Check RBR empty or not using polling method
		return LPC_UART0->RBR;					//return READ data
		
		}

//		void delay(unsigned int a)
//{
//  unsigned int i,j;
//  for(i=0;i<a;i++)
//  for(j=0;j<5000;j++);
//}