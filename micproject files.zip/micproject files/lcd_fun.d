.\lcd_fun.o: lcd_fun.c
.\lcd_fun.o: lcd_header.h
.\lcd_fun.o: C:\Keil\ARM\Inc\NXP\LPC17xx\lpc17xx.h
.\lcd_fun.o: C:\Keil\ARM\CMSIS\Include\core_cm3.h
.\lcd_fun.o: C:\Keil\ARM\ARMCC\bin\..\include\stdint.h
.\lcd_fun.o: C:\Keil\ARM\CMSIS\Include\core_cmInstr.h
.\lcd_fun.o: C:\Keil\ARM\CMSIS\Include\core_cmFunc.h
.\lcd_fun.o: C:\Keil\ARM\Inc\NXP\LPC17xx\system_LPC17xx.h
