#include <lpc214x.h>
#include <stdio.h>

// Function to introduce delay in milliseconds
void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 6000; j++);
}

// Function to initialize UART0 for serial communication
void UART0_init(void) {
    PINSEL0 |= 0x00000005;  // Enable UART0 on P0.0 (TX) and P0.1 (RX)
    U0LCR = 0x83;           // 8-bit data, 1 stop bit, DLAB=1
    U0DLM = 0;
    U0DLL = 97;             // Baud rate 9600 (PCLK = 15MHz)
    U0LCR = 0x03;           // DLAB=0
}

// Function to transmit a single character via UART0
void UART0_TxChar(char ch) {
    while (!(U0LSR & 0x20));  // Wait for THR to be empty
    U0THR = ch;
}

// Function to transmit a string via UART0
void UART0_TxString(char *str) {
    while (*str)
        UART0_TxChar(*str++);
}

// Function to initialize ADC
void ADC_init() {
    PINSEL1 |= (1 << 24);   // P0.28 as AD0.1 (ADC input pin)
    AD0CR = 0x00200402;     // Enable ADC, select channel 1 (AD0.1), set CLKDIV=4
}

// Function to read the ADC value
unsigned int read_adc() {
    AD0CR |= (1 << 24);               // Start ADC conversion on channel 1
    while (!(AD0GDR & (1U << 31)));   // Wait for conversion to complete
    return (AD0GDR >> 6) & 0x3FF;     // Extract 10-bit result
}

int main() {
    UART0_init();  // Initialize UART0 for communication
    ADC_init();    // Initialize ADC for soil moisture sensor input

    while (1) {
        unsigned int moisture = read_adc();  // Read the ADC value

        // Send the ADC value to the serial monitor
        char msg[50];
        sprintf(msg, "ADC Value: %d\r\n", moisture);
        UART0_TxString(msg);

        // Print soil moisture status based on ADC value
        if (moisture < 500) {
            UART0_TxString("Soil is Dry\r\n");
        } else {
            UART0_TxString("Soil is Wet\r\n");
        }

        delay_ms(1000);  // Delay 1 second before reading again
    }
}
