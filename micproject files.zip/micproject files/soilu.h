#include <LPC214x.h>

#define LIGHT (1 << 16)
#define DRY_THRESHOLD 25

void ADC_Init(void);
unsigned int ADC_Read(void);
void UART1_Init(void);
void UART1_SendString(const char *str);
void Timer0_Init(void);
void Timer0_Delay_Seconds(unsigned int seconds);


void ADC_Init(void)
{
    // Set P0.28 as AD0.1
    PINSEL1 |= (1 << 24);   // 0b01 at bits 24-25
    PINSEL1 &= ~(1 << 25);

    // Enable ADC0 (10-bit mode, burst = 0, PDN = 1)
    AD0CR = 0x00200602;  // CLKDIV=6, PDN=1, select AD0.1 (bit 1)
}

unsigned int ADC_Read(void)
{
    AD0CR |= (1 << 24);  // Start conversion now

    while (!(AD0GDR & (1U << 31)));  // Wait for DONE bit

    return (AD0GDR >> 6) & 0x3FF;  // Extract 10-bit result
}

void UART1_Init(void)
{
    // P0.8 = TXD1, P0.9 = RXD1
    PINSEL0 |= (1 << 16) | (1 << 18);
    PINSEL0 &= ~((1 << 17) | (1 << 19));

    U1LCR = 0x83;       // 8-bit data, 1 stop bit, DLAB = 1
    U1DLL = 97;         // Baud rate 9600 @ 15MHz
    U1DLM = 0;
    U1LCR = 0x03;       // DLAB = 0
}

void UART1_SendString(const char *str)
{
    while (*str)
    {
        while (!(U1LSR & 0x20));  // Wait for THR empty
        U1THR = *str++;
    }
}

void Timer0_Init(void)
{
    T0TCR = 0x02; // Reset Timer0
    T0PR = 59999; // Prescaler: 60MHz / (59999+1) = 1kHz (1ms tick)
    T0TCR = 0x01; // Enable Timer0
}

void Timer0_Delay_Seconds(unsigned int seconds)
{
    T0TCR = 0x02; // Reset counter
    T0TCR = 0x01; // Start Timer

    while (T0TC < (seconds * 1000)); // Wait for seconds * 1000 ms

    T0TCR = 0x00; // Stop Timer
}
