/*Program to display a character on LCD*/
#include<lpc17xx.h>

/*MACROs definition*/
#define RS (1 << 10)
//#define RW (1 << 12)
#define EN (1 << 11)
#define DATA (0xFF << 15)

void lcd_config(void);
void lcd_cmd(unsigned char cmd);
void lcd_data(unsigned char data);
void lcd_str(unsigned char *ptr);
void lcd_num(unsigned int num);
void delay(unsigned int a);