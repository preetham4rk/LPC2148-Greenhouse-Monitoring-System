#include <lpc214x.h>
#include <stdint.h>
#include <stdio.h>

// DHT11 Pin (P1.16)
#define DHT11_PIN (1 << 16)

// Simple delay in milliseconds
void delay_ms(uint16_t j) {
    uint16_t x, i;
    for(i = 0; i < j; i++)
        for(x = 0; x < 6000; x++);
}

// Simple delay in microseconds
void delay_us(uint16_t j) {
    uint16_t x, i;
    for(i = 0; i < j; i++)
        for(x = 0; x < 7; x++);
}

int main(void) {
    uint8_t humidity_int, humidity_dec, temp_int, temp_dec, checksum, i;
    uint8_t data[5];
    char buffer[64];
    uint8_t bit_data;

    // UART1 Initialization
    PINSEL0 |= 0x00050000;       // P0.8 -> TXD1, P0.9 -> RXD1
    U1LCR = 0x83;                // Enable DLAB, 8-bit, 1 stop bit, no parity
    U1DLM = 0x00;
    U1DLL = 0x61;                // 9600 baud at 15 MHz
    U1LCR = 0x03;                // Disable DLAB

    while (1) {
        #include <LPC214x.h>
#include <stdio.h>

#define DHT11_PIN P1_21   // Define GPIO pin for DHT11 Data (P1.21)

// UART1 initialization function
void UART1_Init(void) {
    U1LCR = 0x83;     // Enable DLAB (Divisor Latch Access Bit)
    U1DLM = 0x00;     // Set the Divisor for the desired baud rate
    U1DLL = 97;       // For 9600 baud rate with 12MHz PCLK
    U1LCR = 0x03;     // Disable DLAB (Data Access Bit)
}

void UART1_SendChar(char c) {
    while (!(U1LSR & 0x20));  // Wait for the UART1 to be ready
    U1THR = c;                 // Send the character via UART1
}

void UART1_SendString(char* str) {
    while (*str) {
        UART1_SendChar(*str++);
    }
}

// DHT11 Initialization
void DHT11_Init(void) {
    IO1DIR |= (1 << 21);  // Set P1.21 as output for DHT11 Data
}

// Generate the start pulse for DHT11 (sensor requires this pulse)
void DHT11_Start(void) {
    IO1SET = (1 << 21);   // Set P1.21 high (3.3V)
    for (int i = 0; i < 18; i++);  // Delay for 18 ms
    IO1CLR = (1 << 21);   // Set P1.21 low (0V)
    for (int i = 0; i < 20; i++);  // Delay for 20 ms
    IO1SET = (1 << 21);   // Set P1.21 high again
}

// Read data from DHT11
unsigned char DHT11_ReadData(void) {
    unsigned char i, data = 0;

    // Wait for the sensor response (DHT11 will pull the line low for a short period)
    while (!(IO1PIN & (1 << 21))); // Wait for P1.21 to go high
    for (i = 0; i < 8; i++) {
        // Read each bit of data
        if (IO1PIN & (1 << 21)) {
            data |= (1 << (7 - i));  // Set the corresponding bit in data byte
        }
        while (IO1PIN & (1 << 21));  // Wait for the pin to go low
        while (!(IO1PIN & (1 << 21))); // Wait for the pin to go high again
    }
    return data;  // Return the read data
}

int main(void) {
    unsigned char temp, humidity;
    char message[40];

    UART1_Init();  // Initialize UART1 for Bluetooth communication
    DHT11_Init();  // Initialize DHT11 sensor

    while (1) {
        DHT11_Start();  // Start communication with DHT11
        temp = DHT11_ReadData();  // Read temperature from DHT11
        humidity = DHT11_ReadData();  // Read humidity from DHT11

        // Send the data over Bluetooth
        sprintf(message, "Temp: %d C, Humidity: %d %%", temp, humidity);
        UART1_SendString(message);

        // Add a delay to avoid continuous transmission
        for (int i = 0; i < 5000000; i++);  // Simple delay
    }
}

}
