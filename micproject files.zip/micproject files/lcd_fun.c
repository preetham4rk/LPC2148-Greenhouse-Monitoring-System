#include "lcd_header.h"

void lcd_config(void)
{
 LPC_GPIO0->FIODIR |= RS | EN | DATA ;
 lcd_cmd(0x38);// 8-bit 2 line display mode
 lcd_cmd(0x0E);// display on cursor on
 lcd_cmd(0x01);// clear screen
 lcd_cmd(0x80);//msg to display in first row 

}


void lcd_cmd(unsigned char cmd)
{
 LPC_GPIO0->FIOCLR = DATA;		 //clear DATA lines
 LPC_GPIO0->FIOSET = (cmd<<15);	 //load Data to DATA lines
 LPC_GPIO0->FIOCLR = RS;		 //RS=0 for cmd mode
 //LPC_GPIO0->FIOCLR = RW;		 //RW=0 for write mode
 LPC_GPIO0->FIOSET = EN;		 //EN=1
 delay(10); 
 LPC_GPIO0->FIOCLR = EN;		 //EN=0

}

void lcd_data(unsigned char data)
{
 LPC_GPIO0->FIOCLR = DATA;		  //clear DATA lines
 LPC_GPIO0->FIOSET = (data<<15);  //load data to DATA lines
 LPC_GPIO0->FIOSET = RS;		  //RS=1 for DATA mode
 //LPC_GPIO0->FIOCLR = RW;		 //RW=0 for write mode
 LPC_GPIO0->FIOSET = EN;		  //EN=1
 delay(10); 
 LPC_GPIO0->FIOCLR = EN;		  //EN=0

}

void lcd_str(unsigned char *ptr)
{
  while(*ptr != '\0')
  {
	lcd_data(*ptr);
	ptr++;
  }
}
void lcd_num(unsigned int num)
{
  if(num)
  {
	lcd_num(num/10);
	lcd_data(num%10+0x30);
  }
  }
void delay(unsigned int a)
{
  unsigned int i,j;
  for(i=0;i<a;i++)
  for(j=0;j<6000;j++);
}