mq3.o: mq3.c
